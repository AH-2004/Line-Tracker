public class asdf
{
    public void f();

    public void g3333333333333333333();

    integerthisthingisawesomenotit y;    

    String s1;
    String s2;
}